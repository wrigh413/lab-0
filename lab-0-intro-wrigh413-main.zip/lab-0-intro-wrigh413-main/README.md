# Lab 0 Code Template

No files here - follow [lab 0](https://github.com/ece362-purdue/labs/tree/main/lab0-intro/README.md) to learn how to create a new project in this repository and add files to it.

When you are submitting to Gradescope, you'll submit this repository on GitHub.
